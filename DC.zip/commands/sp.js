module.exports = {
    name: 'sp',
    description: "spotify",
    execute(message, args){


            if(message.member.roles.cache.has('976090543702564915')){
                message.channel.send("**Spotify**\nEmail: decemberave@joshnia.xyz\nPassword: eleynpremium ");
            }else {
                message.channel.send('you dont have the right  perms to use this command');
            }
          
    }

}

