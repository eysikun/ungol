module.exports = {
    name: 'rrage',
    description: "Sets up a reaction role message!",
    async execute(message, args, Discord, client) {
        const channel = '978706972020977726';
        const plus18role = message.guild.roles.cache.find(role => role.name === "+18");
        const minus17role = message.guild.roles.cache.find(role => role.name === "-17");
        
        const plus18Emoji = "🔞";
        const minus17Emoji = "⭕";
        

        
 
      //  const plus18Emoji = client.emojis.find(emoji => emoji.name === ":o:");
      //  const minus17Emoji = client.emojis.find(emoji => emoji.name === ":underage:");

        let embed = new Discord.MessageEmbed()
            .setColor('#e42643')
            .setImage('https://media.discordapp.net/attachments/978718969559146617/979508393142288425/received_607694956986480.jpeg?width=776&height=566')
         /*  .setTitle('Age Role\n'
               + `${plus18Emoji} for ${plus18role}\n`
               + `${minus17Emoji} for -17`) */
           
            .setTitle('Age Role')
            .setDescription(`**${plus18Emoji} for ${plus18role}**\n`
                            + `**${minus17Emoji} for ${minus17role}**`);
            
            
            
            
 
        let messageEmbed = await message.channel.send({embeds: [embed]});
        messageEmbed.react(plus18Emoji);
        messageEmbed.react(minus17Emoji);
 
        client.on('messageReactionAdd', async (reaction, user) => {
            if (reaction.message.partial) await reaction.message.fetch();
            if (reaction.intent) await reaction.fetch();
            if (user.bot) return;
            if (!reaction.message.guild) return;
 
            if (reaction.message.channel.id == channel) {
                if (reaction.emoji.name === plus18Emoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.add(plus18role);
                }
                if (reaction.emoji.name === minus17Emoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.add(minus17role);
                }
            } else {
                return;
            }
 
        });
 
        client.on('messageReactionRemove', async (reaction, user) => {
 
            if (reaction.message.partial) await reaction.message.fetch();
            if (reaction.partial) await reaction.fetch();
            if (user.bot) return;
            if (!reaction.message.guild) return;
 
 
            if (reaction.message.channel.id == channel) {
                if (reaction.emoji.name === plus18Emoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.remove(plus18role);
                }
                if (reaction.emoji.name === minus17Emoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.remove(minus17role);
                }
            } else {
                return;
            }
        });
    }
 
}   