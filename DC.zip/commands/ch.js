module.exports = {
    name: 'ch',
    description: "Course Hero",
    execute(message, args){


            if(message.member.roles.cache.has('976090543702564915')){
                message.channel.send("**Course Hero**\nEmail: ufaqq@eluvit.com\nPassword: 123123");
            }else {
                message.channel.send('you dont have the right  perms to use this command');
            }
          
    }

}

