module.exports = {
    name: 'ds',
    description: "salbahe kame",
    execute(message, args, Discord){
         
        const newEmbed = new Discord.MessageEmbed()
        .setColor('#FF82AC')
        .setTitle("**Dangerous Squad**")
        .setURL('https://www.facebook.com/DangerousSquadPH')
        .setDescription('ASPIRING STREAMERS')
        .setImage('https://scontent.fmnl30-3.fna.fbcdn.net/v/t1.6435-9/131300600_141227637796131_8372210214931046538_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=09cbfe&_nc_eui2=AeHK9-f9IklJ7IuxtO_4nD5XwgrdQQahp_zCCt1BBqGn_OYtwJ62ZfhnsrLOlKdtk8fgb9S_FaxxdBO0gNXVlN56&_nc_ohc=OtDhXGSbaw8AX_gYnmJ&_nc_ht=scontent.fmnl30-3.fna&oh=00_AT-mWl-tyk-nzmrqtWNP-nHUfu_NFTfdSUq5RupwmKjNWg&oe=62B5D440')
        .setFooter('Make sure to like our page!');


        message.channel.send({embeds: [newEmbed]});


    }

}

