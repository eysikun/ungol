module.exports = {
    name: 'rrgender',
    description: "Sets up a reaction role message!",
    async execute(message, args, Discord, client) {
        const channel = '978706972020977726';
        const maleRole = message.guild.roles.cache.find(role => role.name === "Male");
        const femaleRole = message.guild.roles.cache.find(role => role.name === "Female");
        const lgbtqiaRole = message.guild.roles.cache.find(role => role.name === "LGBTQIA+");
 
        const maleEmoji = "🤴";
        const femaleEmoji = "👸";
        const lgbtqiaEmoji = "🌈";

        
 
      //  const plus18Emoji = client.emojis.find(emoji => emoji.name === ":o:");
      //  const minus17Emoji = client.emojis.find(emoji => emoji.name === ":underage:");

        let embed = new Discord.MessageEmbed()
            .setColor('#e42643')
            .setImage('https://cdn.discordapp.com/attachments/978718969559146617/979508393410695218/20220527_061434.jpg')
            .setTitle('Gender Role')

            .setDescription(`**${maleEmoji} for ${maleRole}**\n`
                            + `**${femaleEmoji} for ${femaleRole}**\n`
                            + `**${lgbtqiaEmoji} for ${lgbtqiaRole}**`); 
            
                            

      
            
 
        let messageEmbed = await message.channel.send({embeds: [embed]});
        messageEmbed.react(maleEmoji);
        messageEmbed.react(femaleEmoji);
        messageEmbed.react(lgbtqiaEmoji);
 
        client.on('messageReactionAdd', async (reaction, user) => {
            if (reaction.message.partial) await reaction.message.fetch();
            if (reaction.intent) await reaction.fetch();
            if (user.bot) return;
            if (!reaction.message.guild) return;
 
            if (reaction.message.channel.id == channel) {
                if (reaction.emoji.name === maleEmoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.add(maleRole);
                }
                if (reaction.emoji.name === femaleEmoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.add(femaleRole);
                }
                if (reaction.emoji.name === lgbtqiaEmoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.add(lgbtqiaRole);
                }
                
            } else {
                return;
            }
 
        });
 
        client.on('messageReactionRemove', async (reaction, user) => {
 
            if (reaction.message.partial) await reaction.message.fetch();
            if (reaction.partial) await reaction.fetch();
            if (user.bot) return;
            if (!reaction.message.guild) return;
 
 
            if (reaction.message.channel.id == channel) {
                if (reaction.emoji.name === maleEmoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.remove(maleRole);
                }
                if (reaction.emoji.name === femaleEmoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.remove(femaleRole);
                }
                if (reaction.emoji.name === lgbtqiaEmoji) {
                    await reaction.message.guild.members.cache.get(user.id).roles.remove(lgbtqiaRole);
                }
            } else {
                return;
            }
        });
    }
 
}   