const { Client, Intents} = require('discord.js');

const Discord = require('discord.js');

const { MessageMentions: { USERS_PATTERN } } = require('discord.js');

function getUserFromMention(mention) {
	// The id is the first and only match found by the RegEx.
	const matches = mention.matchAll(USERS_PATTERN).next().value;

	// If supplied variable was not a mention, matches will be null instead of an array.
	if (!matches) return;

	// The first element in the matches array will be the entire mention, not just the ID,
	// so use index 1.
	const id = matches[1];

	return client.users.cache.get(id);
}

const {MessageEmbed} = require('discord.js');

// const client = new Discord.Client({partials: ["MESSAGE", "CHANNEL", "REACTION"]});  

// const client = new Discord.Client({partials:[ "MESSAGE", "GUILD_MEMBER", "GUILD_SCHEDULED_EVENT", "CHANNEL", "REACTION", "USER"]});

 const client = new Discord.Client({intents: ["GUILDS","GUILD_MESSAGES", "GUILD_MESSAGE_REACTIONS", "DIRECT_MESSAGE_REACTIONS", "GUILD_PRESENCES", "GUILD_EMOJIS_AND_STICKERS"]}); 

// const client = new Client({Intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.DIRECT_MESSAGE_REACTIONS]}); 

const prefix = '-';

const fs = require('fs');

client.commands = new Discord.Collection();

const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for(const file of commandFiles){

    const command = require(`./commands/${file}`);

    client.commands.set(command.name, command);
}


client.once('ready', () => {
    console.log('eysi is online');
});



client.on('message', message => {
    if(!message.content.startsWith(prefix) || message.author.bot) return;

    const args = message.content.slice(prefix.length).split(/ +/);
    const command = args.shift().toLocaleLowerCase();

    if(command === 'ping'){
        client.commands.get('ping').execute(message, args);
    } else if (command === 'ds'){
        client.commands.get('ds').execute(message, args, Discord);
    } else if (command === 'ch'){
        client.commands.get('ch').execute(message, args);
    } else if (command === 'sp'){
        client.commands.get('sp').execute(message, args);
    }  else if (command === 'rrage'){
        client.commands.get('rrage').execute(message, args, Discord, client);
    } else if (command === 'rrgender'){
        client.commands.get('rrgender').execute(message, args, Discord, client);
    }
})


client.login('NzA0NjMyODAxMDkzMjIyNDIx.GkujMB.vVpLbWkpjqaAspZFPd-kS1OsLgYb1MCWjJOyxM');

